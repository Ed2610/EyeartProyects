import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { ProductosComponent } from './components/productos/productos.component';
import { ContactoComponent } from './components/contacto/contacto.component';
import { AcercaDeComponent } from './components/acerca-de/acerca-de.component';
import { ServiciosComponent } from './components/servicios/servicios.component';
import { ListProductosComponent } from './components/admin/list-productos/list-productos.component';
import { AgregarCategoriasComponent } from './components/admin/agregar-categorias/agregar-categorias.component';
import { ListCategoriasComponent } from './components/admin/list-categorias/list-categorias.component';
import { AgregarProductosComponent } from './components/admin/agregar-productos/agregar-productos.component';
import { LoginComponent } from './components/forms/login/login.component';
import { RegistroComponent } from './components/forms/registro/registro.component';
import { UsuarioComponent } from './components/admin/usuario/usuario.component';
import { PedidoComponent } from './components/pedido/pedido.component';

export const routes: Routes = [
    {path: '', component: HomeComponent}
    ,
    {path: 'productos', component: ProductosComponent}
    ,
    {path: 'contacto', component: ContactoComponent}
    ,
    {path: 'acerca', component: AcercaDeComponent}
    ,
    {path: 'servicios', component: ServiciosComponent},

    {path: 'login', component: LoginComponent},

    {path: 'registro', component: RegistroComponent},

    {path: 'pedido', component: PedidoComponent},

    //Seccion admin
    {path: 'lista-productos', component: ListProductosComponent},
    {path: 'agregar-producto', component: AgregarProductosComponent},
    {path: 'add-categoria', component: AgregarCategoriasComponent},
    {path: 'listar-categoria', component: ListCategoriasComponent},
    {path: 'listar-usuarios', component: UsuarioComponent},

    {path: '**', redirectTo: '',pathMatch: 'full'}
    ];
