import { TestBed } from '@angular/core/testing';

import { EditarpedidoService } from './editarpedido.service';

describe('EditarpedidoService', () => {
  let service: EditarpedidoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EditarpedidoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
