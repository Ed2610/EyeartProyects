import { TestBed } from '@angular/core/testing';

import { AgregarpedidoService } from './agregarpedido.service';

describe('AgregarpedidoService', () => {
  let service: AgregarpedidoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AgregarpedidoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
