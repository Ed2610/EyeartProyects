import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UsuariosService {
  private myPORT: string;
  private myApiUrl: string;


  constructor(private http: HttpClient) {
    this.myPORT = "http://localhost:3000";
    this.myApiUrl = "/usuarios"
   }

   listarUsuario(){
    return this.http.get(this.myPORT+this.myApiUrl);
  }

  retornarUsuario(id: number){
    return this.http.get(this.myPORT+this.myApiUrl+'/'+id);
  }

  agregarUsuario(usuario : any){
    return this.http.post(this.myPORT+this.myApiUrl, usuario);
   }

  actualizarUsuario(usuario : any, id : number){
   return this.http.put(this.myPORT+this.myApiUrl+'/'+id, usuario);
   }

  eliminarUsuario(id : number){
   return this.http.delete(this.myPORT+this.myApiUrl+'/'+id);
   }
   
}
