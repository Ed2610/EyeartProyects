import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ProductosService {

  private myPORT:string;
  private myApiUrl:string;

  constructor(private http: HttpClient) {
    this.myPORT = "http://localhost:3000";
    this.myApiUrl = "/productos"
   }

   listarProducto(){
    return this.http.get(this.myPORT+this.myApiUrl);
  }

  retornarProducto(id: number){
    return this.http.get(this.myPORT+this.myApiUrl+'/'+id);
  }

  agregarProducto(producto : any){
    return this.http.post(this.myPORT+this.myApiUrl, producto);
   }

  actualizarProducto(producto : any, id : number){
   return this.http.put(this.myPORT+this.myApiUrl+'/'+id, producto);
   }

  eliminarProducto(id : number){
   return this.http.delete(this.myPORT+this.myApiUrl+'/'+id);
   }
}
