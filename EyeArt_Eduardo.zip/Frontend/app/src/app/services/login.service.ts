import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private myPORT: string;
  private myApiUrl: string;


  constructor(private http: HttpClient) {
    this.myPORT = "http://localhost:3000";
    this.myApiUrl = "/login"
   }

   login(autentificacion : any){
    return this.http.post(this.myPORT+this.myApiUrl, autentificacion);
   }

}
