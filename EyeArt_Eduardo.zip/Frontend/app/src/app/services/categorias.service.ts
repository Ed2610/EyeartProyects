import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CategoriasService {
  private myPORT: string;
  private myApiUrl: string;


  constructor(private http: HttpClient) {
    this.myPORT = "http://localhost:3000";
    this.myApiUrl = "/categorias"
   }

   listarCategoria(){
    return this.http.get(this.myPORT+this.myApiUrl);
   }

   retornarCategoria(id : number){
    return this.http.get(this.myPORT+this.myApiUrl+id);
   }

   agregarCategoria(categoriaE : any){
    return this.http.post(this.myPORT+this.myApiUrl, categoriaE);
   }

   actualizarCategoria(categoriaE : any, id : number){
    return this.http.put(this.myPORT+this.myApiUrl+id, categoriaE);
   }

   eliminarCategoria(id : number){
    return this.http.delete(this.myPORT+this.myApiUrl+id);
   }

}
