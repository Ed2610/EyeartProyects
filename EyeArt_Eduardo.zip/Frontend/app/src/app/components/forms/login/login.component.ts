import { Component } from '@angular/core';
import { FooterComponent } from '../../estructura/footer/footer.component';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { LoginService } from '../../../services/login.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FooterComponent, RouterLink, RouterLinkActive],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  constructor(private LoginService:LoginService){
    
  }
}
