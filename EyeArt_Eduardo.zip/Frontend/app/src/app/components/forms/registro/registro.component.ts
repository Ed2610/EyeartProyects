import { Component } from '@angular/core';
import { FooterComponent } from '../../estructura/footer/footer.component';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-registro',
  standalone: true,
  imports: [FooterComponent, RouterLink, RouterLinkActive],
  templateUrl: './registro.component.html',
  styleUrl: './registro.component.css'
})
export class RegistroComponent {

}
