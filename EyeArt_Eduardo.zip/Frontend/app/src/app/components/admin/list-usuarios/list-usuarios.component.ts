import { Component } from '@angular/core';

@Component({
  selector: 'app-list-usuarios',
  standalone: true,
  imports: [],
  templateUrl: './list-usuarios.component.html',
  styleUrl: './list-usuarios.component.css'
})
export class ListUsuariosComponent {

}
