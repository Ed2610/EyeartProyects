import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { FooterComponent } from '../../estructura/footer/footer.component';
import { CategoriasService } from '../../../services/categorias.service';
import { FormsModule} from '@angular/forms';


@Component({
  selector: 'app-agregar-categorias',
  standalone: true,
  imports: [RouterLink, FooterComponent, FormsModule],
  templateUrl: './agregar-categorias.component.html',
  styleUrl: './agregar-categorias.component.css'
})
export class AgregarCategoriasComponent {
  categoria : any;

  categoriaE={
    idCategoria: 0,
    descripcion: ""
  }
  
  constructor(
    private CategoriasService:CategoriasService,
  ){ }

  agregarCategoria(){
    this.CategoriasService.agregarCategoria(this.categoriaE).subscribe(result=>this.categoria=result)
  }


}
