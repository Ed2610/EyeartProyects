import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { RouterOutlet } from '@angular/router';
import { CurrencyPipe } from '@angular/common';
import { FormsModule, NgModel } from '@angular/forms';
import { ProductosService } from '../../../services/productos.service';
import { CategoriasService } from '../../../services/categorias.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-agregar-productos',
  standalone: true,
  imports: [RouterLink,CurrencyPipe,RouterOutlet, FormsModule],
  templateUrl: './agregar-productos.component.html',
  styleUrl: './agregar-productos.component.css'
})
export class AgregarProductosComponent {
categorias : any;
productos:any;
producto = {
  Nombre:'',
  DescripcionProducto:'',
  Precio:null,
  Stock:null,
  url_foto:'',
  Categoria_idCategoria:''


}



constructor(private ProductosService:ProductosService,private router: Router, private CategoriasService:CategoriasService){

  this.CategoriasService.listarCategoria().subscribe(result=>this.categorias=result);


}

agregar(){this.ProductosService.agregarProducto(this.producto)
  .subscribe(result=>this.productos=result);

  alert('Agregado exitosamente')
  this.router.navigate(['/lista-productos']);
}




}
