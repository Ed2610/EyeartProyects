import { Component } from '@angular/core';
import { FooterComponent } from '../../estructura/footer/footer.component';
import { RouterLink } from '@angular/router';
import { ProductosService } from '../../../services/productos.service';
import { CategoriasService } from '../../../services/categorias.service';
import { CurrencyPipe } from '@angular/common';

@Component({
  selector: 'app-list-productos',
  standalone: true,
  imports: [FooterComponent, RouterLink,CurrencyPipe],
  templateUrl: './list-productos.component.html',
  styleUrl: './list-productos.component.css'
})
export class ListProductosComponent {
productos: any;
producto = {
  id:0,
  Nombre:'',
  DescripcionProducto:'',
  precio:0,
  stock:0,
  url_foto:'',

}
categoria:any;

constructor(private ProductosService:ProductosService){

  this.ProductosService.listarProducto()
  .subscribe(result=>this.productos=result)


}

eliminar(id : number){
  this.ProductosService.eliminarProducto(id).subscribe((datos:any)=>{
    this.ProductosService.listarProducto().subscribe(result=>this.productos=result);
  });
}
}
