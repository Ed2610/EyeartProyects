const bodyParser = require('body-parser');
const cors = require('cors');
const express = require('express');
const db = require('./db/conexion.js');
const rutasCategorias = require('./routes/categorias.js');
const controlesCategorias = require('./controllers/categorias.js');
const app = express();

app.use(cors());

app.use(bodyParser.json())
const PUERTO = 3000;

db.connect(error=>{
    if(error) throw error
    console.log('Conexion a la base de datos exitosa');
})


app.listen(PUERTO, ()=>{
    console.log('Servidor iniciado en el puerto '+PUERTO);
})

app.use(rutasCategorias);
