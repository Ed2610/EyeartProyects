import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { ProductosComponent } from './components/productos/productos.component';
import { ContactoComponent } from './components/contacto/contacto.component';
import { AcercaDeComponent } from './components/acerca-de/acerca-de.component';
import { ServiciosComponent } from './components/servicios/servicios.component';
import { ListProductosComponent } from './components/admin/list-productos/list-productos.component';
import { AgregarCategoriasComponent } from './components/admin/agregar-categorias/agregar-categorias.component';
import { ListCategoriasComponent } from './components/admin/list-categorias/list-categorias.component';

export const routes: Routes = [
    {path: '', component: HomeComponent}
    ,
    {path: 'productos', component: ProductosComponent}
    ,
    {path: 'contacto', component: ContactoComponent}
    ,
    {path: 'acerca', component: AcercaDeComponent}
    ,
    {path: 'servicios', component: ServiciosComponent},

    //Seccion admin
    {path: 'lista-productos', component: ListProductosComponent},
    {path: 'add-categoria', component: AgregarCategoriasComponent},
    {path: 'listar-categoria', component: ListCategoriasComponent},
    {path: '**', redirectTo: '',pathMatch: 'full'}
    ];
