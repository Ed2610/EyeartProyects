import { Component } from '@angular/core';

@Component({
  selector: 'app-add-mod-productos',
  standalone: true,
  imports: [],
  templateUrl: './add-mod-productos.component.html',
  styleUrl: './add-mod-productos.component.css'
})
export class AddModProductosComponent {

}
