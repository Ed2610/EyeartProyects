import { Component } from '@angular/core';
import { FooterComponent } from '../../estructura/footer/footer.component';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-list-productos',
  standalone: true,
  imports: [FooterComponent, RouterLink],
  templateUrl: './list-productos.component.html',
  styleUrl: './list-productos.component.css'
})
export class ListProductosComponent {

}
