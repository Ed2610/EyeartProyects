import { Component } from '@angular/core';
import { FooterComponent } from '../../estructura/footer/footer.component';
import { CategoriasService } from '../../../services/categorias.service';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-list-categorias',
  standalone: true,
  imports: [FooterComponent, RouterLink],
  templateUrl: './list-categorias.component.html',
  styleUrl: './list-categorias.component.css'
})
export class ListCategoriasComponent {
  categoria : any;

  constructor(private CategoriasService:CategoriasService){
    this.CategoriasService.listarCategoria()
    .subscribe(result=>this.categoria=result)

  }




}
